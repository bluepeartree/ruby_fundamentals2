# To get stared

Type:

```
gem install colorize
gem install pry
```

and then run each snail program.

## Big Snail

My first attempt using OOP and several classes.

## Medium Snail

Got it down to one class.

## Small Snail

Got it down to one method.
