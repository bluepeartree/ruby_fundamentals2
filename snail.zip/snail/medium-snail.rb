require 'pry'
require 'colorize'

class Square

  def initialize(values)
    @snail = []
    @lines = [
      -> { @all.map(&:shift) },
      -> { @all.shift },
      -> { @all.map(&:pop) },
      -> { @all.pop.reverse }
    ]

    setup_all(values)
    process_line until @all.empty?
    display_snail
  end

  def setup_all(values)
    length = Math.sqrt(values.size).to_i
    @all = (0...length).map { |row| values[row * length, length] }
  end

  def process_line
    display
    @snail << @lines.rotate!.first.call
  end

  def display_snail
    puts "\nSnail: #{@snail.flatten!}\n".yellow
  end

  def display
    display_snail
    max_length = @all.flatten.map(&:to_s).map(&:length).max + 1

    @all.each do |row|
      puts row.map { |value| value.to_s.ljust(max_length, ' ') }.join.green
    end
  end

end

def square(num)
  (1..num * num).to_a
end

Square.new(square(4))
