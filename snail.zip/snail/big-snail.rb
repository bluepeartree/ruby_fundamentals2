require 'pry'
require 'colorize'

class Point

  @@all = []

  attr_accessor :x, :y
  attr_reader :value

  def initialize(x, y, value)
    @x = x
    @y = y
    @value = value.to_s
    @@all << self
  end

  def delete
    @@all.delete_at @@all.index { |point| point.x == x && point.y == y }
  end

  def self.all
    @@all
  end

  def self.max_length
    @@all.max_by { |point| point.value.length }.value.length + 1
  end

end

class Line

  @@current_line = :top

  def self.next_line
    @@current_line =  case @@current_line
                      when :top    then :right
                      when :right  then :bottom
                      when :bottom then :left
                      when :left   then :top
                      end
  end

  def self.current_line
    @@current_line
  end

end


class Square

  def initialize(values)

    length = Math.sqrt(values.size).to_i

    current_num = 0
    (1..length).each do |x|
      (1..length).each do |y|
        Point.new(x, y, values[current_num])
        current_num += 1
      end
    end

    @snail = []

    until Point.all.empty?
      display
      process_line
    end
    puts "Final Snail: #{@snail}".light_yellow
  end

  def process_line
    send(Line.current_line)
    Line.next_line
  end

  def top
    Point.all.select { |point| point.x == top_point}.each do |point|
      @snail << point.value
      point.delete
    end
  end

  def right
    Point.all.select { |point| point.y == right_point}.each do |point|
      @snail << point.value
      point.delete
    end
  end

  def left
    Point.all.select { |point| point.y == left_point}.reverse.each do |point|
      @snail << point.value
      point.delete
    end
  end

  def bottom
    Point.all.select { |point| point.x == bottom_point}.reverse.each do |point|
      @snail << point.value
      point.delete
    end
  end

  def top_point
    Point.all.min_by(&:x).x
  end

  def right_point
    Point.all.max_by(&:y).y
  end

  def left_point
    Point.all.min_by(&:y).y
  end

  def bottom_point
    Point.all.max_by(&:x).x
  end

  def rows
    Point.all.group_by(&:x)
  end

  def display
    rows.each do |row|
      row[1].each do |point|
        print "#{point.value.rjust(Point.max_length, ' ')}".green
      end
      puts
    end
    puts
    puts "Snail: #{@snail}".yellow
    puts
  end

end

def square(num)
  (1..num * num).to_a
end

Square.new(square(4))
