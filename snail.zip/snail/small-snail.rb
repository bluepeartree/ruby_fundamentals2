def snail(values)
  lines = [ -> { values.map(&:shift).reverse },
            -> { values.shift },
            -> { values.map(&:pop) },
            -> { values.pop.reverse } ]

  snail = []
  snail << lines.rotate!.first.call until values.empty?
  snail.flatten
end

def snail_test(results)
  results == [1, 2, 3, 4, 8, 12, 16, 15, 14, 13, 9, 5, 6, 7, 11, 10] ? 'nice' : 'incorrect'
end

results = snail [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]

puts "Snail: #{results}"
puts "Your snail looks #{snail_test(results)}."
